<footer class="footer">
  <div class="container-fluid clearfix">
    <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright ©  <a href="#" target="_blank">Softonic Solutions</a> 2020</span>
    
    </span>
  </div>
</footer>