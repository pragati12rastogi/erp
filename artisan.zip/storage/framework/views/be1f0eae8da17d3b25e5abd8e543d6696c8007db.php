<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
    
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Hsn Summary</h4>
            </div>
            <?php if(Auth::user()->hasPermissionTo('hsn.create') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN) ): ?>
            <div class="col-md-2 text-right" >
              <button onclick='return $("#add_hsn_modal").modal("show");' class="btn btn-inverse-primary btn-sm"><?php echo e(__("Add HSN")); ?></button>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="table-responsive">
          <table id="hsn_table" class="table ">
            <thead>
              <tr>
                <th>Sr.no.</th>
                <th>Hsn No</th>
                <th>Created At</th>
                <th>Created By/Updated BY</th>
                <?php if(Auth::user()->hasPermissionTo('hsn.edit') || Auth::user()->hasPermissionTo('hsn.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                <th>Action</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $hsns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($h->hsn_no); ?></td>
                    
                    <td><?php echo e(date('d-m-Y',strtotime($h->created_at))); ?></td>
                    <td><?php echo e(!empty($h->created_by)?$h->created_by_user['name']:""); ?>  <?php echo e(!empty($h->updated_by)? '/'.$h->updated_by_user->name : ""); ?></td>
                    
                    <?php if(Auth::user()->hasPermissionTo('hsn.edit') || Auth::user()->hasPermissionTo('hsn.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                
                    <td>
                      <?php if(Auth::user()->hasPermissionTo('hsn.edit') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                      
                        <a onclick='edit_hsn_modal("<?php echo e($h->id); ?>")' class="btn btn-success text-white">
                            <i class="mdi mdi-pen"></i>
                        </a>
                      <?php endif; ?>
                      <?php if(Auth::user()->hasPermissionTo('hsn.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                      
                        <a onclick='return $("#<?php echo e($h->id); ?>_hsn").modal("show");' class="btn btn-danger text-white">
                            <i class=" mdi mdi-delete-forever"></i>
                        </a>
                      <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/hsn/list.blade.php ENDPATH**/ ?>