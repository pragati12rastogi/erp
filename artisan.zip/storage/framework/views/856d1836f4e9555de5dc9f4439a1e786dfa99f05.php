<!DOCTYPE html>
<html>
<head>
  <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(env('APP_NAME')); ?></title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- CSRF Token -->
  <meta name="_token" content="<?php echo e(csrf_token()); ?>">
    <?php if(!empty($general_settings) && !empty($general_settings['favicon']) && file_exists(public_path().'/images/general/'.$general_settings['favicon']) ): ?>
      <link rel="shortcut icon" href="<?php echo e(asset('/images/general/'.$general_settings['favicon'])); ?>">
    <?php else: ?>
      <link rel="shortcut icon" href="<?php echo e(asset('/favicon.ico')); ?>">
    <?php endif; ?>
  
  
  <!-- plugin css -->
  <?php echo Html::style('assets/plugins/@mdi/font/css/materialdesignicons.min.css'); ?>

  <?php echo Html::style('assets/plugins/perfect-scrollbar/perfect-scrollbar.css'); ?>

  <!-- end plugin css -->
  
  
  <?php echo Html::style('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css'); ?>

  <?php echo Html::style('plugins/datatables-responsive/css/responsive.bootstrap4.min.css'); ?>

  <?php echo Html::style('plugins/datatables-responsive/css/responsive.bootstrap4.css'); ?>

  <?php echo Html::style('plugins/datatables-buttons/css/buttons.bootstrap4.min.css'); ?>

  <?php echo Html::style('plugins/datatables-fixedcolumns/css/fixedColumns.bootstrap4.min.css'); ?>    
  <?php echo Html::style('plugins/datatables-fixedheader/css/fixedHeader.bootstrap4.min.css'); ?>


  <!-- Select2 -->
  <?php echo Html::style('/plugins/select2/css/select2.min.css'); ?>

  <?php echo Html::style('/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css'); ?>


  <?php echo Html::style('plugins/bootstrap-tagsinput-latest/src/bootstrap-tagsinput.css'); ?>



  <?php echo $__env->yieldPushContent('plugin-styles'); ?>

  <!-- common css -->
  <?php echo Html::style('css/app.css'); ?>

  <!-- end common css -->

  <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body data-base-url="<?php echo e(url('/')); ?>">

  <div class="container-scroller" id="app">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">
      <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>

  <!-- jQuery -->
  <?php echo Html::script('plugins/jquery/jquery.min.js'); ?>

  <!-- JQuery -->

  <!-- jQuery UI 1.11.4 -->
  <?php echo Html::script('plugins/jquery-ui/jquery-ui.min.js'); ?>

  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>


  <!-- Bootstrap 4 -->
  <?php echo Html::script('/plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>

  
  <!-- DataTables  & Plugins -->
  <?php echo Html::script('plugins/datatables/jquery.dataTables.min.js'); ?>

  <?php echo Html::script('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js'); ?>


  <?php echo Html::script('/plugins/datatables-buttons/js/dataTables.buttons.min.js'); ?>

  <?php echo Html::script('/plugins/datatables-buttons/js/buttons.bootstrap4.min.js'); ?>

  <?php echo Html::script('/plugins/jszip/jszip.min.js'); ?>

  <?php echo Html::script('/plugins/pdfmake/pdfmake.min.js'); ?>

  <?php echo Html::script('/plugins/pdfmake/vfs_fonts.js'); ?>

  <?php echo Html::script('/plugins/datatables-buttons/js/buttons.html5.min.js'); ?>

  <?php echo Html::script('/plugins/datatables-buttons/js/buttons.print.min.js'); ?>

  <?php echo Html::script('/plugins/datatables-buttons/js/buttons.colVis.min.js'); ?>

  <!-- Select2 -->
  <?php echo Html::script('/plugins/select2/js/select2.full.min.js'); ?>


  
  <!-- daterangepicker -->
  <?php echo Html::script('/plugins/moment/moment.min.js'); ?>

  <?php echo Html::script('/plugins/daterangepicker/daterangepicker.js'); ?>

  <!-- Tempusdominus Bootstrap 4 -->
  <?php echo Html::script('/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js'); ?>

  <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>

  <?php echo Html::script('plugins/bootstrap-tagsinput-latest/src/bootstrap-tagsinput.js'); ?>

  <!-- base js -->
  <!-- <?php echo Html::script('js/app.js'); ?> -->
  <?php echo Html::script('assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js'); ?>

  <!-- end base js -->

  <!-- plugin js -->
  <?php echo $__env->yieldPushContent('plugin-scripts'); ?>
  <!-- end plugin js -->

  <!-- common js -->
  <?php echo Html::script('assets/js/off-canvas.js'); ?>

  <?php echo Html::script('assets/js/hoverable-collapse.js'); ?>

  <?php echo Html::script('assets/js/misc.js'); ?>

  <?php echo Html::script('assets/js/settings.js'); ?>

  <?php echo Html::script('assets/js/todolist.js'); ?>

  <!-- end common js -->

  <!-- jquery-validation -->
  <?php echo Html::script('/plugins/jquery-validation/jquery.validate.min.js'); ?>

  <?php echo Html::script('/plugins/jquery-validation/additional-methods.min.js'); ?>

  
  <script>
    var admin_url = '<?php echo e(url("/")); ?>';
    $(function() {
      // $.noConflict();
      $('.select2').select2();

      $('.select2bs4').select2({
        theme: 'bootstrap4'
      })

      $('.datepicker').datetimepicker({
        format: 'L'
      });

    });

    function markread(id) {
      var a = $('#countNoti').text();
      $.ajax({
        type:"Get",
        url:"<?php echo e(route('unreadsinglenotification')); ?>",
        data:{'id':id},
        dataType:'JSON',
        success:function(response) {
          if(a > 0) {
            var b = a - 1;
            if(b > 0) {
              $('#countNoti').text(b);
              $('#' + id).css('background', 'white');
            } else {
              $('#countNoti').hide('fast');
            }
          }
        },
        error: function(error){
          console.log(error.responseText);
        }
      });
    }
  </script>
  <?php echo Html::script('/assets/plugins/chartjs/chart.min.js'); ?>

  <?php echo Html::script('/assets/js/chart.js'); ?>

  <?php echo $__env->yieldPushContent('custom-scripts'); ?>
  
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/layouts/master.blade.php ENDPATH**/ ?>