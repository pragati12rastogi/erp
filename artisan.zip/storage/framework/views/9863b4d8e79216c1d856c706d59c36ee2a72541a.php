<html>
<head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Profit'],
          ['Total Stock Price (Rs.<?php echo e($stock_added["sum_stock_spend"]); ?>)',     <?php echo e($stock_added['sum_stock_spend']); ?>],
          ['Total Expense (Rs. <?php echo e($recieve["sum_recieve"]); ?>)',      <?php echo e($recieve['sum_recieve']); ?>],
          ['Total Recieve (Rs. <?php echo e($expense["sum_expense"]); ?>)',  <?php echo e($expense["sum_expense"]); ?>],
       
        ]);

        var options = {
          title: 'Profit Chart'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
      <div style="margin: auto 20%;">
          <div id="piechart" style="width: 1000px; height: 1000px;"></div>
      </div>
    
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/charts/chartpdf.blade.php ENDPATH**/ ?>