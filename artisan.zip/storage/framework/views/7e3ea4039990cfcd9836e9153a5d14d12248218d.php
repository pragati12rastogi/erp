<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
    
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Vendor Summary</h4>
            </div>
            <?php if(Auth::user()->hasPermissionTo('vendors.create') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                  
            <div class="col-md-2 text-right" >
                <a onclick='return $("#add_vendor_modal").modal("show");' class="btn btn-inverse-primary btn-sm "><?php echo e(__("Add Vendor")); ?></a>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="table-responsive">
          <table id="vendor_table" class="table ">
            <thead>
              <tr>
                <th>Name</th>
                <th>Firm Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Created At</th>
                <th>Created By/Updated By</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($vendor->name); ?></td>
                  <td><?php echo e($vendor->firm_name); ?></td>
                  <td><?php echo e($vendor->email); ?></td>
                  <td><?php echo e($vendor->phone); ?></td>
                  <td><?php echo e(date('Y-m-d',strtotime($vendor->created_at))); ?></td>
                  <td>
                    
                    <?php echo e(!empty($vendor->created_by)?$vendor->created_by_user->name:''); ?><?php echo e(!empty($vendor->updated_by)? '/'.$vendor->updated_by_user->name:''); ?></td>
                    
                  <td>
                  <?php if(Auth::user()->hasPermissionTo('vendors.edit') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                    <a  onclick='return $("#<?php echo e($vendor->id); ?>_vendor_edit_modal").modal("show");' class="btn btn-success text-white">
                        <i class="mdi mdi-pen"></i>
                    </a>
                  <?php endif; ?>
                  <?php if(Auth::user()->hasPermissionTo('vendors.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                      
                    <a onclick='return $("#<?php echo e($vendor->id); ?>_vendor").modal("show");' class="btn btn-danger text-white">
                        <i class=" mdi mdi-delete-forever"></i>
                    </a>
                  <?php endif; ?>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project\resources\views/vendor/list.blade.php ENDPATH**/ ?>