
<?php $__env->startSection('title', 'Local Stock Summary'); ?>

<?php $__env->startPush('style'); ?>
<style>
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
    }

    /* Firefox */
    input[type=number] {
    -moz-appearance: textfield;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
  <?php echo Html::script('/js/user_distributer.js'); ?>

    <script>
        $(function() {
            $("#stock_table").DataTable({
              dom: 'Blfrtip',
              buttons: [
              {
                  extend:'excelHtml5',
                  exportOptions: {
                      columns: [ 0, 1, 2,3,4 ] 
                  }
              },
              {
                  extend:'pdfHtml5',
                  exportOptions: {
                      columns: [0, 1, 2,3,4  ] //Your Column value those you want
                  }
              }
              
              ],

              "order":[[0,'desc']]
            });
            
            <?php $__currentLoopData = $given_distribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $did =>$dv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              jQuery('#payment_form_<?php echo e($dv->id); ?>').validate({ // initialize the plugin
                rules: {
                    transaction_type:{
                      required:true,
                    },
                    amount:{
                      required:true,
                    },
                    transaction_id:{
                      required:true,
                    },
                    cheque_no:{
                      required:true,
                    },
                    bank_name:{
                      required:true
                    },
                    ifsc:{
                      required:true
                    },
                    account_name:{
                      required:true
                    }
                },
                errorPlacement: function(error,element)
                {
                    if($(element).attr('type') == 'radio')
                    {
                        error.insertAfter(element.parent());
                    }
                    else if($(element).is('select'))
                    {
                        error.insertAfter(element.parent());
                    }
                    else{
                        error.insertAfter(element);
                    }
                        
                }
              });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
        
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12">
  <?php echo $__env->make('flash-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  <?php if(Auth::user()->hasPermissionTo('local-stock-distribution.create') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
    <?php echo $__env->make('user_stock.local_distribution_creation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-9">
                <h4 class="card-title">Local Stock Summary</h4>
            </div>
            
        </div>
        
        <div class="table-responsive">
            <div class="row">
              <div class="col-md-4">
                  <b>Selling Amount: </b><span>Rs. <?php echo e(empty($sell['sum_sell'])? 0:$sell['sum_sell']); ?></span>
              </div>
              <div class="col-md-4">
                  <b>Receive Amount: </b><span>Rs. <?php echo e(empty($recieve['sum_recieve'])? 0:$recieve['sum_recieve']); ?></span>
              </div>
              <div class="col-md-4">
                  <b>Balance Amount: </b>
                  <?php
                    $sale = (float) $sell['sum_sell'];
                    $recieve = (float) $recieve['sum_recieve'];
                  ?>
                  <span>Rs. <?php echo e($sale-$recieve); ?></span>
              </div>
            </div>
            <table id="stock_table" class="table ">
                <thead>
                    <tr>
                    <th>Invoice No.</th>
                    <th>User Name</th>
                    <th>Phone</th>
                    <th>Total Amount</th>
                    <th>Created At</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $given_distribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($h->invoice_no); ?></td>
                        <td><?php echo e($h->user_name); ?></td>
                        <td><?php echo e($h->phone); ?></td>
                        <td>Rs. <?php echo e($h->total_cost); ?></td>
                        <td><?php echo e(date('d-m-Y',strtotime($h->created_at))); ?></td>
                        <td>
                        <?php if(Auth::user()->hasPermissionTo('local-stock-distribution.show')): ?>
                            <a href="<?php echo e(url('local-stock-distribution/'.$h->id)); ?>" class="btn btn-success ">
                            Invoice
                            </a>
                        <?php endif; ?>
                        
                        <?php if(Auth::user()->hasPermissionTo('local-stock-distribution.destroy') ): ?>
                            <?php if(empty($h->is_cancelled)): ?>
                              <?php if(Auth::user()->hasPermissionTo('local-stock-distribution.payment')): ?>
                              <a onclick='return $("#<?php echo e($h->id); ?>_pay").modal("show");'  class="btn  btn-warning text-white"> Pay </a>  
                              <?php endif; ?>
                              <a onclick='return $("#<?php echo e($h->id); ?>_cancel").modal("show");' class="btn btn-danger text-white">
                              Cancel
                              </a>
                            <?php else: ?>
                                <b>Status:</b> Cancelled / <b>By:</b> <?php echo e(!empty($h->updated_by)? $h->updated_by_user->name:''); ?> 
                            <?php endif; ?>
                        <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
      </div>
    </div>
  </div>
</div>
<?php $__currentLoopData = $given_distribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $did =>$dv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="<?php echo e($dv->id); ?>_pay" class="delete-modal modal fade" role="dialog">
        <div class="modal-dialog ">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-heading">Payment</h4>
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              
            </div>
            <div class="modal-body text-center">
              <div class="col-md-12">
                <?php
                  
                  $paid_amt = 0;
                  foreach($dv->payment as $pid => $p){
                    $paid_amt += $p->amount;
                  }

                ?>
                <form id="payment_form_<?php echo e($dv->id); ?>" method="post" action="<?php echo e(route('local.distribution.payment')); ?>">
                  <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-md-3 text-left text-small">
                      <label><b> Total Order Amount :</b></label>
                      <span> Rs. <?php echo e($dv->total_cost); ?></span>
                    </div>
                    <div class="col-md-3 text-left text-small">
                      <label><b> Total Amount Paid :</b></label>
                      <span> Rs. <?php echo e($paid_amt); ?></span>
                    </div>
                    <div class="col-md-3 text-left text-small">
                      <label>
                      <b> Pending Payment:</b>
                      </label>
                      <span> Rs. <?php echo e(($dv->total_cost-$paid_amt<0)? abs($dv->total_cost-$paid_amt)."(Extra amt paid)":$dv->total_cost-$paid_amt); ?></span>
                    </div>
                  </div>
                  <hr>
                  <div class="row text-left">
                    <input type="hidden" name="local_order_id" value="<?php echo e(Crypt::encrypt($dv->id)); ?>">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="control-label" for="first-name">
                          Amount: <span class="required">*</span>
                        </label>
                        <input type="number" max="<?php echo e($dv->total_cost-$paid_amt); ?>" value="<?php echo e($dv->total_cost-$paid_amt); ?>" name="amount" id="amount" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="control-label" for="first-name">
                          Transaction Type: <span class="required">*</span>
                        </label>
                        <select name="transaction_type" data-type="<?php echo e($dv->id); ?>" class="form-control select2 transaction_type">
                          <option value="">Select transaction method</option>
                          <option value="cash">Cash</option>
                          <option value="online">Online</option>
                          <option value="cheque">Cheque</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6" id="online_div_<?php echo e($dv->id); ?>" style="display:none">
                      <div class="form-group">
                        <label class="control-label" for="first-name">
                          Transaction ID: <span class="required">*</span>
                        </label>
                        <input type="text" class="form-control" name="transaction_id">
                      </div>
                    </div>
                    <div class="col-md-12" id="cheque_div_<?php echo e($dv->id); ?>" style="display:none">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="control-label" for="first-name">
                              Cheque Number: <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" name="cheque_no">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="control-label" for="first-name">
                              Bank Name: <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" name="bank_name">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="control-label" for="first-name">
                              IFSC: <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" name="ifsc">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="control-label" for="first-name">
                              Account Owner Name: <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" name="account_name">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success translate-y-3" id="modal-submit" >Submit</button>
            </form>
              <button type="reset" class="btn btn-inverse-dark translate-y-3" data-dismiss="modal">cancel</button>
              
            </div>
        </div>
        </div>
    </div>

    <div id="<?php echo e($dv->id); ?>_cancel" class="delete-modal modal fade" role="dialog">
      <div class="modal-dialog modal-sm">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="delete-icon"></div>
            </div>
            <div class="modal-body text-center">
            <h4 class="modal-heading">Are You Sure ?</h4>
            <p>Do you really want to Cancel this product from stock distribution? This process cannot be undone.</p>
            </div>
            <div class="modal-footer">
            <form method="post" action="<?php echo e(url('/local-stock-distribution/'.$dv->id)); ?>" class="pull-right">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field("DELETE")); ?>

                                
                            
            
                <button type="reset" class="btn btn-gray translate-y-3" data-dismiss="modal">No</button>
                <button type="submit" class="btn btn-danger">Yes</button>
            </form>
            </div>
        </div>
      </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/user_stock/distribution_index.blade.php ENDPATH**/ ?>