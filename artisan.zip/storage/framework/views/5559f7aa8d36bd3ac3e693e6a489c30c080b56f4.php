<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Item Summary</h4>
            </div>
            <div class="col-md-2 text-right" >
              <?php if(Auth::user()->hasPermissionTo('item.create') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                      
                <a onclick='return $("#item_add_modal").modal("show");' class="btn btn-inverse-primary btn-sm"><?php echo e(__("Add Item")); ?></a>
              <?php endif; ?>
            </div>
        </div>
        
        <div class="table-responsive">
          <table id="item_table" class="table ">
            <thead>
              <tr>
                <th>Sr.no.</th>
                <th>Item Name</th>
                <th>Category</th>
                <th>Image</th>
                <th>HSN</th>
                <th>GST</th>
                <th>Created At</th>
                <th>Created By/Updated By</th>
                <?php if(Auth::user()->hasPermissionTo('item.edit') || Auth::user()->hasPermissionTo('item.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                <th>Action</th>
                <?php endif; ?>
                
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->category->name); ?></td>
                    <td>
                      <?php if(count($item->images)>0): ?>
                        <?php if($item->images[0]['photo'] != '' && file_exists(public_path().'/uploads/items/'.$item->images[0]['photo']) ): ?>
                          <img class="img-thumbnail"  src="<?php echo e(url('uploads/items/'.$item->images[0]['photo'])); ?>" title="<?php echo e($item->name); ?>">
                        <?php endif; ?>
                      <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($item->hsn->hsn_no); ?>

                    </td>
                    <td>
                        <?php echo e($item->gst_percent->percent); ?> %
                    </td>
                    <td><?php echo e(date('d-m-Y',strtotime($item->created_at))); ?></td>
                    <td><?php echo e(!empty($item->created_by)?$item->created_by_user['name']:""); ?><?php echo e(!empty($item->updated_by)? '/'.$item->updated_by_user->name :''); ?></td>
                    
                    <?php if(Auth::user()->hasPermissionTo('item.edit') || Auth::user()->hasPermissionTo('item.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                    <td>
                      <?php if(Auth::user()->hasPermissionTo('item.edit') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                        <a onclick='return $("#<?php echo e($item->id); ?>_item_edit_modal").modal("show");' class="btn btn-success text-white">
                            <i class="mdi mdi-pen"></i>
                        </a>
                      <?php endif; ?>
                      <?php if(Auth::user()->hasPermissionTo('item.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                        <a onclick='return $("#<?php echo e($item->id); ?>_item").modal("show");' class="btn btn-danger text-white">
                            <i class=" mdi mdi-delete-forever"></i>
                        </a>
                      <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/item/list.blade.php ENDPATH**/ ?>