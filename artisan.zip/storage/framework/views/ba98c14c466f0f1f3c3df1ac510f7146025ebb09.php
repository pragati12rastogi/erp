
<?php $__env->startSection('title', 'General Setting'); ?>

<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $(function() {
            
            jQuery('#general_master_form').validate({ // initialize the plugin
                rules: {

                    
                    project_name:{
                        required:true,
                    },
                    APP_URL:{
                        required:true,
                    }
                    
                },
                errorPlacement: function(error,element)
                {
                    if($(element).attr('type') == 'radio')
                    {
                        error.insertAfter(element.parent());
                    }
                    else if($(element).is('select'))
                    {
                        error.insertAfter(element.parent());
                    }
                    else{
                        error.insertAfter(element);
                    }
                        
                }
            });
        });
        
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">

  <div class="col-lg-12 grid-margin stretch-card">
      
    <div class="card">
    <?php echo $__env->make('flash-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">General Setting</h4>
            </div>
            
        </div>
        
        <div class="row">
          <div class="col-md-12">
            <form id="general_master_form" method="post" enctype="multipart/form-data" action="<?php echo e(route('general.setting.save')); ?>" data-parsley-validate class="form-horizontal form-label-left">
                <?php echo e(csrf_field()); ?>

                
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>
                            Project Name: <span class="required">*</span>
                            </label>

                            <input placeholder="Please enter Project name" type="text" id="a1" name="project_name"
                            value="<?php echo e(env('APP_NAME')); ?>" class="form-control currency-icon-picker ">
                            <small class="text-muted"><i class="mdi mdi-alert-octagon-outline"></i> Project name is basically your Project
                            Title.</small>
                            <?php $__errorArgs = ['project_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6" style="display:none">

                        <div class="form-group">
                            <label>APP URL:<span class="required">*</span></label>
                            <input placeholder="http://" type="text" id="app_url" name="APP_URL" value="<?php echo e(env('APP_URL')); ?>"
                            class="form-control">
                            <small class="text-muted"><i class="mdi mdi-alert-octagon-outline"></i> Try changing domain will cause serious
                            error.</small>
                            <?php $__errorArgs = ['APP_URL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-9">
                            <label>Logo:<span class="required">*</span></label>
                            <input type="file" id="first-name" name="logo" class="form-control p-2" accept="image/*">
                            <small class="text-muted"><i class="mdi mdi-alert-octagon-outline"></i> Please choose a site logo (supported
                                format: <b>PNG, JPG, JPEG, GIF</b>).</small>
                            </div>

                            <div class="col-custom col-md-3">
                            <?php if(!empty($setting)): ?>
                            <div class="badge-secondary card card-body">

                                <img title="Current Logo" src=" <?php echo e(url('/images/general/'.$setting->logo)); ?>" class="w-100">

                            </div>
                            <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">

                        <div class="row">
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label>Favicon:</label><span class="required">*</span>
                                    <input type="file" id="first-name" name="favicon" class="form-control p-2" accept="image/*">
                                    <small class="text-muted"><i class="mdi mdi-alert-octagon-outline"></i> Please choose a site favicon (supported
                                    format: <b>PNG, JPG, JPEG</b>).</small>
                                </div>
                            </div>

                            <div class="col-custom col-md-3">
                                <?php if(!empty($setting)): ?>
                                <div class="badge-secondary card card-body">
                                    <center><img class="img-responsive w-100" title="Current Favicon"
                                        src=" <?php echo e(url('/images/general/'.$setting->favicon)); ?>" ></center>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>OneSignal App Id: </label>
                            <input name="ONESIGNAL_APP_ID" type="text" value="<?php echo e(env('ONESIGNAL_APP_ID')); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>OneSignal Rest API Key: </label>
                            <input name="ONESIGNAL_REST_API_KEY" type="text" value="<?php echo e(env('ONESIGNAL_REST_API_KEY')); ?>" class="form-control">
                        </div>
                    </div>

                    <div class="col-xs-12 col-md-12">
                        <hr>
                        <button type="submit" class="btn btn-dark mt-3">Save</button>
                    </div>
                </div>
                
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/setting/general_master.blade.php ENDPATH**/ ?>