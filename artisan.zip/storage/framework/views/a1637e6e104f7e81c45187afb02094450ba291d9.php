<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
    
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Category Summary</h4>
            </div>
            <?php if(Auth::user()->hasPermissionTo('category.create') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN) ): ?>
            <div class="col-md-2 text-right" >
              <button onclick='return $("#add_category_modal").modal("show");' class="btn btn-inverse-primary btn-sm"><?php echo e(__("Add Category")); ?></button>
            </div>
            <?php endif; ?>
        </div>
        <div class="table-responsive">
          <table id="category_table" class="table ">
            <thead>
              <tr>
                <th>Sr.no.</th>
                <th>Name</th>
                <th>Image</th>
                <th>Created At</th>
                <th>Created By/Updated By</th>
                <?php if(Auth::user()->hasPermissionTo('category.edit') || Auth::user()->hasPermissionTo('category.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                
                <th>Action</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($cat->name); ?></td>
                    
                    <td>
                      <?php if($cat->image != '' && file_exists(public_path().'/uploads/category/'.$cat->image) ): ?>
                          <img class="img-thumbnail"  src="<?php echo e(url('uploads/category/'.$cat->image)); ?>" title="<?php echo e($cat->name); ?>">
                      <?php endif; ?>
                    </td>
                    
                    <td><?php echo e(date('d-m-Y',strtotime($cat->created_at))); ?></td>
                    <td><?php echo e(!empty($cat->created_by)?$cat->created_by_user['name']:""); ?>  <?php echo e(!empty($cat->updated_by)? '/'.$cat->updated_by_user->name:""); ?></td>
                    <?php if(Auth::user()->hasPermissionTo('category.edit') || Auth::user()->hasPermissionTo('category.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                
                    <td>
                      <?php if(Auth::user()->hasPermissionTo('category.edit') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                        <a onclick='return $("#<?php echo e($cat->id); ?>_category_edit_modal").modal("show");' class="btn btn-success text-white">
                            <i class="mdi mdi-pen"></i>
                        </a>
                      <?php endif; ?>
                      <?php if(Auth::user()->hasPermissionTo('category.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                        <a onclick='return $("#<?php echo e($cat->id); ?>_cat").modal("show");' class="btn btn-danger text-white">
                            <i class=" mdi mdi-delete-forever"></i>
                        </a>
                      <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/category/list.blade.php ENDPATH**/ ?>