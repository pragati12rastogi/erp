
<?php $__env->startSection('title', 'Invoice Master'); ?>

<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $(function() {
            
            jQuery('#invoice_master_form').validate({ // initialize the plugin
                rules: {

                    
                    prefix:{
                        required:true,
                    },
                    suffix_number_length:{
                        digits: true,
                        required: true
                    }
                    
                },
                errorPlacement: function(error,element)
                {
                    if($(element).attr('type') == 'radio')
                    {
                        error.insertAfter(element.parent());
                    }
                    else if($(element).is('select'))
                    {
                        error.insertAfter(element.parent());
                    }
                    else{
                        error.insertAfter(element);
                    }
                        
                }
            });
        });
        
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">

  <div class="col-lg-12 grid-margin stretch-card">
      
    <div class="card">
    <?php echo $__env->make('flash-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Invoice Master</h4>
            </div>
            
        </div>
        
        <div class="row">
          <div class="col-md-12">
            <form id="invoice_master_form" method="post" enctype="multipart/form-data" action="<?php echo e(route('save.invoice.master')); ?>" data-parsley-validate class="form-horizontal form-label-left">
                <?php echo e(csrf_field()); ?>

                
                <div class="row">
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label" for="first-name">
                                Invoice Number Prefix: <span class="required">*</span>
                            </label>
                            <input name="prefix" value="<?php echo e(!empty($invoice_setting)?$invoice_setting['prefix']:''); ?>" type="text" maxlength="255" class="form-control text-capitalize" >
                            <?php $__errorArgs = ['prefix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label" for="first-name">
                                Suffix Invoice Number: <span class="required">*</span>
                            </label>
                            <input name="suffix_number_length" id="suffix_number_length" value="<?php echo e(!empty($invoice_setting)?$invoice_setting['suffix_number_length']:''); ?>" type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" class="form-control" >
                            <?php $__errorArgs = ['suffix_number_length'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    

                </div>
                
                <div class="col-xs-12 ">
                    <?php if(!empty($invoice_setting)): ?>
                    <span><b>Updated By:</b> <?php echo e($invoice_setting->updated_by_user['name']); ?></span>
                    <?php endif; ?>
                    <hr>
                    <button type="submit" class="btn btn-dark mt-3">Save</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project\resources\views/setting/invoice_master.blade.php ENDPATH**/ ?>