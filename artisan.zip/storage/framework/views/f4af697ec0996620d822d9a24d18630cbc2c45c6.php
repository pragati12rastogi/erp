<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>