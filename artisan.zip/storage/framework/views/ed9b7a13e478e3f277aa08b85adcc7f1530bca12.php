<!DOCTYPE html>
<html lang="en">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<style>
    .page-break {
            page-break-inside: avoid;       
    }
    @page  {
        margin-top:50px;
        footer: page-footer;
        font-family: 'Arial Narrow', Arial, sans-serif;
        font-size: 14px;
    }
    .center{
        text-align: center;
    }
    .tablestyle{
        border-collapse: collapse;
        width: 100%;
    }
    .tablestyle, th, td{
        border: 1px solid black;
        padding: 4px;
    }
    .lesswidth{
        width: 35%;
    } 
    .left{
        text-align: left;
        font-weight: 100;
        font-size: 16px;
    }
    .justify{
        text-align: justify;
        font-weight: 100;
        font-size: 16px;
    }
    th{
        font-size: 14px;
    }
    </style>
     <script>
            
    </script>
       
</head>
<body>
    <div >
        
        <div class="center">
            <h2>Users Summary</h3>
        </div>
        
        <br>
        <table class="tablestyle" >
            
            <tr> 
                <th>Id</th>
                <th>Role Name</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Firm Data</th>
                <th>Address</th>
                <th>Bank Details</th>

            </tr>
            <?php $__currentLoopData = $table_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td class="center"> <?php echo e($data['id']); ?> </td>
                <td class="center"> <?php echo e($data['role_name']); ?> </td>
                <td class="center"> <?php echo e($data['name']); ?> </td>
                <td class="center">
                    <p><b>Email:</b><?php echo e($data['email']); ?></p>  
                    <p><b>Mobile:</b><?php echo e($data['mobile']); ?></p>  
                </td>
                <td class="center"> 
                    <p><b>Firm Name:</b><?php echo e($data['firm_name']); ?></p>  
                    <p><b>GST Number:</b><?php echo e($data['gst_no']); ?></p>  
                </td>
                <td class="center">
                    <p><b>State:</b><?php echo e($data['state_name']); ?></p>
                    <p><b>District:</b><?php echo e($data['district_name']); ?></p> 
                    <p><b>Area:</b><?php echo e($data['area_name']); ?></p> 
                    <p><b>Address:</b><?php echo e($data['address']); ?></p>  
                </td>
                <td class="center">
                <?php if($data['role_name'] != App\Custom\Constants::ROLE_ADMIN): ?>
                    <p><b>Bank Name:</b><?php echo e($data['bank_name']); ?></p>
                    <p><b>Name on Passbook:</b><?php echo e($data['name_on_passbook']); ?></p>
                    <p><b>IFSC:</b><?php echo e($data['ifsc']); ?></p>
                    <p><b>Account Number:</b><?php echo e($data['account_no']); ?></p>
                <?php endif; ?>
                    <p><b>PAN:</b><?php echo e($data['pan_no']); ?></p>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        
    </div>
 
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/pdf/usertemplate.blade.php ENDPATH**/ ?>