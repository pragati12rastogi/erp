
<?php $__env->startSection('title', 'Distribution Summary'); ?>

<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<script>
  if ($("#pieChart").length) {
      var pieChartCanvas = $("#pieChart")
          .get(0)
          .getContext("2d");
      var pieChart = new Chart(pieChartCanvas, {
          type: "pie",
          data: {
              datasets: [
                  {
                      data: ["<?php echo e($stock_added['sum_stock_spend']); ?>", "<?php echo e($recieve['sum_recieve']); ?>", "<?php echo e($expense['sum_expense']); ?>"],
                      backgroundColor: [
                          ChartColor[0],
                          ChartColor[1],
                          ChartColor[2]
                      ],
                      borderColor: [
                          ChartColor[0],
                          ChartColor[1],
                          ChartColor[2]
                      ]
                  }
              ],
              labels: ["Total Stock Price", "Total Expense", "Total Recieve"]
          },
          options: {
              responsive: true,
              animation: {
                  animateScale: true,
                  animateRotate: true
              },
              legend: {
                  display: false
              },
              legendCallback: function(chart) {
                  var text = [];
                  text.push('<div class="chartjs-legend"><ul>');
                  for (
                      var i = 0;
                      i < chart.data.datasets[0].data.length;
                      i++
                  ) {
                      text.push(
                          '<li><span style="background-color:' +
                              chart.data.datasets[0].backgroundColor[i] +
                              '">'
                      );
                      text.push("</span>");
                      if (chart.data.labels[i]) {
                          text.push(chart.data.labels[i]);
                      }
                      text.push("</li>");
                  }
                  text.push("</div></ul>");
                  return text.join("");
              }
          }
      });
      document.getElementById(
          "pie-chart-legend"
      ).innerHTML = pieChart.generateLegend();
  }
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="p-4 pr-5 border-bottom bg-light d-sm-flex justify-content-between">
        <iframe src="<?php echo e(route('profit-chart.pdf.download')); ?>" style="display:none;" name="frame"></iframe>

        <h4 class="card-title mb-0">Profit chart</h4> 
        <span>
            <button title="Print Order" onclick="frames['frame'].print()" class="btn btn-dark btn-block">
                Download PDF
            </button>
        </span>

        <div id="pie-chart-legend" class="mr-4"></div>
      </div>
      <div class="card-body d-flex">
        <canvas class="my-auto" id="pieChart" height="130"></canvas>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/charts/index.blade.php ENDPATH**/ ?>