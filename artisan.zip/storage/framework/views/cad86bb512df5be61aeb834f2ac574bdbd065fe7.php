
<?php $__env->startSection('title', 'Role Summary'); ?>

<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $(function() {
            $("#role_table").DataTable({
                dom: 'Blfrtip',
                buttons: [
                    {
                    extend:'excelHtml5',
                    exportOptions: {
                        columns: [ 0, 1 ] 
                    }
                    },
                    {
                    extend:'pdfHtml5',
                        exportOptions: {
                            columns: [ 0, 1 ] //Your Column value those you want
                        }
                    }
                ]
            });
            jQuery('#role_form').validate({ // initialize the plugin
                rules: {

                    name: {
                        required: true,
                    },
                    'permission[]':{
                        required: true
                    }
                }
            });

            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            jQuery('#role_form_<?php echo e($role->id); ?>').validate({ // initialize the plugin
                rules: {

                    name: {
                        required: true,
                    },
                    'permission[]':{
                        required: true
                    }
                }
            });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
        
        $(".all_select_permission").click(function(){
            var check_status = this.checked;
            var data_id = $(this).attr('id');
            $("."+data_id).prop('checked', this.checked);
        })

        $(".sub_permission").click(function(){
            var check_status = this.checked;
            var get_class = $(this).attr('class');
            var split_get_class = get_class.split(' ');
            var sub_per_name = split_get_class[1];

            var count_length = $('.'+sub_per_name).length;
            var count_checked_length = $('.'+sub_per_name+':checked').length;

            if(count_length == count_checked_length ){
                $('#'+sub_per_name).prop('checked', true);
            }else{
                $('#'+sub_per_name).prop('checked', false);
            }
        })
        $(".all_select_permission_upd").click(function(){
            var check_status = this.checked;
            var data_id = $(this).attr('id');
            $("."+data_id).prop('checked', this.checked);
        })

        $(".sub_permission_upd").click(function(){
            var check_status = this.checked;
            var get_class = $(this).attr('class');
            var split_get_class = get_class.split(' ');
            var sub_per_name = split_get_class[1];

            var count_length = $('.'+sub_per_name).length;
            var count_checked_length = $('.'+sub_per_name+':checked').length;

            if(count_length == count_checked_length ){
                $('#'+sub_per_name).prop('checked', true);
            }else{
                $('#'+sub_per_name).prop('checked', false);
            }
        }) 
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
    <?php echo $__env->make('flash-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Role Summary</h4>
            </div>
            <div class="col-md-2 text-right" >
              
              <a onclick='return $("#add_role_modal").modal("show");' class="btn btn-inverse-primary btn-sm"><?php echo e(__("Add Role")); ?></a>
            </div>
        </div>
        
        <div class="table-responsive">
          <table id="role_table" class="table ">
            <thead>
              <tr>
                <th>Sr.No.</th>
                <th>Role</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($role->name); ?></td>
                <td>
                  <?php if(Auth::user()->hasPermissionTo('roles.edit') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                    <a class="btn btn-sm btn-success text-white" onclick='return $("#edit_role_modal_<?php echo e($role->id); ?>").modal("show");' >Edit</a>
                  <?php endif; ?>
                  <?php if(Auth::user()->hasPermissionTo('users.index') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                    <a onclick='return $("#<?php echo e($role->id); ?>_role").modal("show");'  class="btn  btn-sm btn-danger text-white"> Delete </a>  
                  <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('roles.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="<?php echo e($role->id); ?>_role" class="delete-modal modal fade" role="dialog">
        <div class="modal-dialog modal-sm">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="delete-icon"></div>
            </div>
            <div class="modal-body text-center">
            <h4 class="modal-heading">Are You Sure ?</h4>
            <p>Do you really want to delete this Role? This process cannot be undone.</p>
            </div>
            <div class="modal-footer">
            <form method="post" action="<?php echo e(route('roles.destroy',$role->id)); ?>" class="pull-right">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field("DELETE")); ?>

                                
                            
            
                <button type="reset" class="btn btn-gray translate-y-3" data-dismiss="modal">No</button>
                <button type="submit" class="btn btn-danger">Yes</button>
            </form>
            </div>
        </div>
        </div>
    </div>
    <?php echo $__env->make('roles.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/roles/index.blade.php ENDPATH**/ ?>