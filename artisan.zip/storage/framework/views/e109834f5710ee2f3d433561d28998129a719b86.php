
<?php $__env->startSection('title', 'Item Summary'); ?>

<?php $__env->startPush('style'); ?>
  <style>
    .other_image_delete_style{
        position: absolute;
        top: 46px;
        left: 12px;

    }
  </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $(function() {
            $("#item_table").DataTable({
                dom: 'Blfrtip',
                buttons: [
                {
                    extend:'excelHtml5',
                    exportOptions: {
                        columns: [ 0, 1, 2,4,5,6 ] 
                    }
                },
                {
                    extend:'pdfHtml5',
                    exportOptions: {
                        columns: [0, 1, 2,4,5,6  ] //Your Column value those you want
                    }
                }
                
                ]
            });
            jQuery('#item_form').validate({ // initialize the plugin
              rules: {
                  name:{
                    required:true,
                  },
                  category_id:{
                    required:true,
                  },
                  hsn_id:{
                    required:true,
                  },
                  gst_percent_id:{
                    required:true,
                  }
                    
                },
                errorPlacement: function(error,element)
                {
                    if($(element).attr('type') == 'radio')
                    {
                        error.insertAfter(element.parent());
                    }
                    else if($(element).is('select'))
                    {
                        error.insertAfter(element.parent());
                    }
                    else{
                        error.insertAfter(element);
                    }
                        
                }
            });

            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              jQuery('#item_form_<?php echo e($item->id); ?>').validate({ // initialize the plugin
                  rules: {
                    name:{
                      required:true,
                    },
                    category_id:{
                      required:true,
                    },
                    hsn_id:{
                      required:true,
                    },
                    gst_percent_id:{
                      required:true,
                    }
                      
                  },
                  errorPlacement: function(error,element)
                  {
                      if($(element).attr('type') == 'radio')
                      {
                          error.insertAfter(element.parent());
                      }
                      else if($(element).is('select'))
                      {
                          error.insertAfter(element.parent());
                      }
                      else{
                          error.insertAfter(element);
                      }
                          
                  }
              });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
        
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12">
        <?php echo $__env->make('flash-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>


<?php echo $__env->make('item.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('item.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="<?php echo e($item->id); ?>_item" class="delete-modal modal fade" role="dialog">
        <div class="modal-dialog modal-sm">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="delete-icon"></div>
            </div>
            <div class="modal-body text-center">
            <h4 class="modal-heading">Are You Sure ?</h4>
            <p>Do you really want to delete this item? This process cannot be undone.</p>
            </div>
            <div class="modal-footer">
            <form method="post" action="<?php echo e(url('/item/'.$item->id)); ?>" class="pull-right">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field("DELETE")); ?>

                                
                            
            
                <button type="reset" class="btn btn-gray translate-y-3" data-dismiss="modal">No</button>
                <button type="submit" class="btn btn-danger">Yes</button>
            </form>
            </div>
        </div>
        </div>
    </div>
    <?php echo $__env->make('item.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/item/index.blade.php ENDPATH**/ ?>