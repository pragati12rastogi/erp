<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-9">
                <h4 class="card-title">User Summary</h4>
            </div>
            
            <div class="col-md-3 text-right">
              <?php if(Auth::user()->hasPermissionTo('users.create') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                <button onclick='return $("#add_user_modal").modal("show");' class="btn btn-inverse-primary btn-sm"><?php echo e(__("Add User")); ?></button>
              <?php endif; ?>
              <div class="btn-group">
                <a href="<?php echo e(route('users.export','excel')); ?>" class="btn btn-dark btn-sm"><?php echo e(__("Excel")); ?></a>
                <a href="<?php echo e(route('users.export','pdf')); ?>" class="btn btn-dark btn-sm"><?php echo e(__("PDF")); ?></a>
              </div>
            </div>
        </div>
        
        <div class="table-responsive">
          <table id="user_table" class="table ">
            <thead>
              <tr>
                <th>Name</th>
                <th>Role</th>
                <th>Firm Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Created At</th>
                <th>Created By/Updated By</th>
                <th>Status</th>
                <?php if(Auth::user()->hasPermissionTo('users.edit') || Auth::user()->hasPermissionTo('users.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                <th>Action</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($user->name); ?></td>
                  <td><?php echo e($user->role->name); ?></td>
                  <td><?php echo e($user->firm_name); ?></td>
                  <td><?php echo e($user->email); ?></td>
                  <td><?php echo e($user->mobile); ?></td>
                  <td><?php echo e(date('Y-m-d',strtotime($user->created_at))); ?></td>

                  <td>
                    
                    <?php echo e(!empty($user->created_by)?$user->created_by_user->name:''); ?><?php echo e(!empty($user->updated_by)? '/'.$user->updated_by_user->name:''); ?></td>
                    
                  <td>
                    <form action="<?php echo e(route('user.status.update',$user->id)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-xs <?php echo e($user->status?'btn-success':'btn-danger'); ?>">
                        <?php echo e($user->status?'Active':'Deactive'); ?>

                        </button>
                    </form>
                  </td>
                  <?php if(Auth::user()->hasPermissionTo('users.edit') || Auth::user()->hasPermissionTo('users.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                  <td>
                    <?php if(Auth::user()->hasPermissionTo('users.edit') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                    <a onclick='edit_users_modal(<?php echo e($user->id); ?>)' class="btn btn-success text-white">
                        <i class="mdi mdi-pen"></i>
                    </a>
                    <?php endif; ?>

                    <?php if(Auth::user()->hasPermissionTo('users.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                    
                    <a onclick='return $("#<?php echo e($user->id); ?>_user").modal("show");' class="btn btn-danger text-white">
                        <i class=" mdi mdi-delete-forever"></i>
                    </a>
                    <?php endif; ?>
                  </td>
                  <?php endif; ?>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/user/list.blade.php ENDPATH**/ ?>