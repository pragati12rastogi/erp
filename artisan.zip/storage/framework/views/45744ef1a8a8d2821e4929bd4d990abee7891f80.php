<nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
  <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
    <a class="navbar-brand brand-logo" href="<?php echo e(url('/')); ?>">
      <?php if(!empty($general_settings) && !empty($general_settings['logo']) && file_exists(public_path().'/images/general/'.$general_settings['logo']) ): ?>
      <img src="<?php echo e(url('/images/general/'.$general_settings['logo'])); ?>" alt="logo" /> 
      <?php else: ?>
      <img src="<?php echo e(url('assets/images/logo.svg')); ?>" alt="logo" /> 
      <?php endif; ?>
    </a>
    <a class="navbar-brand brand-logo-mini" href="<?php echo e(url('/')); ?>">
      <?php if(!empty($general_settings) && !empty($general_settings['favicon']) && file_exists(public_path().'/images/general/'.$general_settings['favicon']) ): ?>
      <img src="<?php echo e(url('/images/general/'.$general_settings['favicon'])); ?>" alt="logo" /> 
      <?php else: ?>
      <img src="<?php echo e(url('assets/images/logo-mini.svg')); ?>" alt="logo" />
      <?php endif; ?> 
    </a>
  </div>
  <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
      <span class="mdi mdi-menu"></span>
    </button>
    <ul class="navbar-nav navbar-nav-left header-links">
      <li class="nav-item d-none d-xl-flex">
        <a href="<?php echo e(url('/')); ?>" class="nav-link">Dashboard 
        </a>
      </li>
    </ul>
    <ul class="navbar-nav navbar-nav-right">
    <li class="nav-item dropdown">
        <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
          <i class="mdi mdi-bell-outline"></i>
          <?php if(auth()->user()->unreadnotifications->where('n_type','=','product_request')->count()): ?>
          <span id="countNoti" class="count bg-success"><?php echo e(auth()->user()->unreadnotifications->where('n_type','=','product_request')->count()); ?></span>
          <?php endif; ?>
        </a>
        <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list pb-0" aria-labelledby="notificationDropdown">
          <a class="dropdown-item py-3 border-bottom">
            <?php if(auth()->user()->unreadnotifications->where('n_type','=','product_request')->count()): ?>
            <p  class="mb-0 font-weight-medium float-left">
              <?php echo e(auth()->user()->unreadnotifications->where('n_type','=','product_request')->count()); ?> new notifications
            </p>
            <span class="badge badge-pill badge-primary float-right">View all</span>
            <?php else: ?>
            <p class="mb-0 font-weight-medium float-left">
              No Notifications
            </p>
            <?php endif; ?>
          </a>
          <?php if(auth()->user()->unreadnotifications->where('n_type','=','product_request')->count()>0): ?>
            <?php $__currentLoopData = auth()->user()->unreadnotifications->where('n_type','=','product_request'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a onclick="markread('<?php echo e($notification->id); ?>')"  href="<?php echo e(url($notification->url)); ?>" class="dropdown-item preview-item py-3">
              <div class="preview-thumbnail">
              <i class="mdi mdi-airballoon m-auto text-primary"></i>
              </div>
              <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal text-dark mb-1"><?php echo e($notification->data['data']); ?></h6>
                <p class="font-weight-light small-text mb-0"> <?php echo e(date('jS M y',strtotime($notification->created_at))); ?> </p>
              </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </div>
      </li>
      <li class="nav-item dropdown d-none d-xl-inline-block">
        <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
          <span class="profile-text d-none d-md-inline-flex"><?php echo e(Auth::user()->name); ?> !</span>
            <?php if(!empty(Auth::user()->profile) && file_exists(public_path().'/uploads/user_profile/'.Auth::user()->profile)): ?>
              <img class="img-xs rounded-circle" src="<?php echo e(url('/uploads/user_profile/'.Auth::user()->profile)); ?>" alt="profile image">
            <?php else: ?>
              <img class="img-xs rounded-circle" src="<?php echo e(url('assets/images/faces/face8.jpg')); ?>" alt="profile image">
            <?php endif; ?>
          </a>
        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
            <a class="dropdown-item mt-2" href="<?php echo e(url('user-profile/update')); ?>"> Manage Accounts </a>
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
      </li>
    </ul>
    <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
      <span class="mdi mdi-menu icon-menu"></span>
    </button>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/layouts/header.blade.php ENDPATH**/ ?>