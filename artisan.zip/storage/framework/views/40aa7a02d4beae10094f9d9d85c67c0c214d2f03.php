
<?php $__env->startSection('title', 'Billing Address Master'); ?>

<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $(function() {
            
            jQuery('#billing_master_form').validate({ // initialize the plugin
                rules: {

                    
                    details:{
                        required:true,
                    }
                    
                },
                errorPlacement: function(error,element)
                {
                    if($(element).attr('type') == 'radio')
                    {
                        error.insertAfter(element.parent());
                    }
                    else if($(element).is('select'))
                    {
                        error.insertAfter(element.parent());
                    }
                    else{
                        error.insertAfter(element);
                    }
                        
                }
            });
        });
        
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">

  <div class="col-lg-12 grid-margin stretch-card">
      
    <div class="card">
    <?php echo $__env->make('flash-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Billing Address Master</h4>
            </div>
            
        </div>
        
        <div class="row">
          <div class="col-md-12">
            <form id="billing_master_form" method="post" enctype="multipart/form-data" action="<?php echo e(route('save.billing.master')); ?>" data-parsley-validate class="form-horizontal form-label-left">
                <?php echo e(csrf_field()); ?>

                
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label" for="first-name">
                                Billing Address: <span class="required">*</span>
                            </label>
                            <textarea name="details" class="form-control ckeditor" ><?php echo e(!empty($billing_setting)?$billing_setting['details']:''); ?></textarea>
                            <?php $__errorArgs = ['details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-xs-12 col-md-12">
                        <button type="submit" class="btn btn-dark mt-3">Save</button>
                    </div>
                </div>
                
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/setting/billing_master.blade.php ENDPATH**/ ?>