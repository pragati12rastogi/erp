

  <div class="col-lg-12 grid-margin stretch-card">
      
    <div class="card">
    
    
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Create Local Distribution</h4>
            </div>
            
        </div>
        
        <div class="row">
          <div class="col-md-12">
            <form id="hsn_form" method="post" enctype="multipart/form-data" action="<?php echo e(url('local-stock-distribution')); ?>" data-parsley-validate class="form-horizontal form-label-left">
                <?php echo e(csrf_field()); ?>

                
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label" for="first-name">
                                User Name: <span class="required">*</span>
                            </label>
                            <input type="text" name="user_name" class="form-control text-capitalize" >
                            <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="first-name">
                                Mobile: <span class="required">*</span>
                            </label>
                            <input type="text" name="phone" class="form-control " oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" maxlength="10" >
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label" for="first-name">
                                Address: <span class="required">*</span>
                            </label>
                            <textarea  name="address" id="address" class="form-control" ></textarea>
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group">
                            
                            <button type="button" class="btn  btn-dark mt-2" onclick="return $('#products_model').modal('show');">Add Product</button>
                            <div class="row">
                                <input type="text" name="prod" id="prod" style="opacity: 0;position: absolute;">
                            </div>
                            
                        </div>
                        <div class="form-group">
                            
                        </div>
                        
                    </div>

                    

                    <div class="col-md-12" id="prod-append-div">

                    </div>

                </div>
                
                <div class="col-xs-12 ">
                    <hr>
                    <button type="submit" class="btn btn-dark mt-3">Save</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

<div id="products_model" class="delete-modal modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="delete-icon"></div>
        </div>
        <div class="modal-body text-center">
            <div class="table-responsive">
                <table id="item_table" class="table ">
                    <thead>
                    <tr>
                        <th></th>
                        <th>Category</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Add</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><input type="checkbox" id="checkbox_<?php echo e($item->id); ?>" class="multiple_item_select" value="<?php echo e($item->id); ?>"></td>
                            
                            <td><?php echo e($item->item->category->name); ?>

                            <input type="hidden" id="modal_prod_cat_<?php echo e($item->id); ?>" value="<?php echo e($item->item->category->name); ?>">
                            </td>
                            <td><?php echo e($item->item->name); ?>

                            <input type="hidden" id="modal_prod_name_<?php echo e($item->id); ?>" value="<?php echo e($item->item->name); ?>">
                            </td>
                            
                            <td>
                                <?php echo e($item->price); ?>

                                <input type="hidden" id="modal_prod_price_<?php echo e($item->id); ?>" value="<?php echo e($item->price); ?>">
                            </td>
                            <td>
                                <?php echo e($item->prod_quantity); ?>

                                <input type="hidden" id="modal_prod_qty_<?php echo e($item->id); ?>" value="<?php echo e($item->prod_quantity); ?>">
                            </td>
                            
                            <td>

                                <div class="d-flex">
                                    <button type="button" class="inc_dec_btn btn btn-dark btn-rounded">-</button>
                                    <input type="number" value="0" min="0" max="<?php echo e($item->prod_quantity); ?>" class="form-control col-md-2 ml-2 mr-2" id="item_prod_<?php echo e($item->id); ?>" onchange="qty_change_func(this)">
                                    <button type="button" class="inc_dec_btn btn btn-dark btn-rounded">+</button>
                                    
                                </div>
                                <span class="error d-flex" id="qty_err_<?php echo e($item->id); ?>"></span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="row bg-inverse-primary p-1">
                <div class="col-md-6">
                    <label class="m-0">Total Price:</label> <span id="modal_total_price"></span>
                </div>
                <div class="col-md-6">
                    <label class="m-0">Total Quantity:</label><span id="modal_total_quantity"></span>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            
            <button type="button" class="btn btn-success translate-y-3" id="modal-submit" >Submit</button>
            <button type="reset" class="btn btn-inverse-dark translate-y-3" data-dismiss="modal">Cancel</button>
        </form>
        </div>
    </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project\resources\views/user_stock/local_distribution_creation.blade.php ENDPATH**/ ?>