
<?php $__env->startSection('title', 'SMS Setting'); ?>

<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $(function() {
            
            jQuery('#sms_master_form').validate({ // initialize the plugin
                rules: {

                    TWILIO_SID:{
                        required:true,
                    },
                    TWILIO_AUTH_TOKEN:{
                        required:true,
                    },
                    TWILIO_NUMBER:{
                        required:true,
                    }
                    
                },
                errorPlacement: function(error,element)
                {
                    if($(element).attr('type') == 'radio')
                    {
                        error.insertAfter(element.parent());
                    }
                    else if($(element).is('select'))
                    {
                        error.insertAfter(element.parent());
                    }
                    else{
                        error.insertAfter(element);
                    }
                        
                }
            });
        });
        
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">

  <div class="col-lg-12 grid-margin stretch-card">
      
    <div class="card">
    <?php echo $__env->make('flash-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">SMS Setting</h4>
            </div>
            
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('sms.setting.save')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label>Twilio SID: <span class="text-red">*</span></label>
                                    <input name="TWILIO_SID" type="text" value="<?php echo e(env('TWILIO_SID')); ?>" class="form-control">
                                </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Twilio Auth Token: <span class="text-red">*</span></label>
                                <input name="TWILIO_AUTH_TOKEN" type="text" value="<?php echo e(env('TWILIO_AUTH_TOKEN')); ?>" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Twilio Number: <span class="text-red">*</span></label>
                                <input name="TWILIO_NUMBER" type="text" value="<?php echo e(env('TWILIO_NUMBER')); ?>" class="form-control">
                            </div>
                        </div>
        
                        <div class="col-md-12">
                            <hr>
                            <button type="submit" class="btn btn-md btn-primary">
                                 Save
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/setting/sms_master.blade.php ENDPATH**/ ?>