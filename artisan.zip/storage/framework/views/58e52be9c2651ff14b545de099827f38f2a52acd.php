<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Role Summary</h4>
            </div>
            <div class="col-md-2 text-right" >
                <?php if(Auth::user()->hasPermissionTo('roles.create') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                    <button onclick='return $("#add_roles_modal").modal("show");' class="btn btn-inverse-primary btn-sm"><?php echo e(__("Add Role")); ?></a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="table-responsive">
          <table id="role_table" class="table ">
            <thead>
              <tr>
                <th>Sr.No.</th>
                <th>Role</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($role->name); ?></td>
                    <td>
                    <?php if(Auth::user()->hasPermissionTo('roles.edit') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                        <a class="btn btn-sm btn-success" href="<?php echo e(route('roles.edit',$role->id)); ?>">Edit</a>
                    <?php endif; ?>
                    <?php if(Auth::user()->hasPermissionTo('users.index') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                        <a onclick='return $("#<?php echo e($role->id); ?>_role").modal("show");'  class="btn  btn-sm btn-danger text-white"> Delete </a>  
                    <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project\resources\views/roles/list.blade.php ENDPATH**/ ?>