<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Stock Summary</h4>
            </div>
            <?php if(Auth::user()->hasPermissionTo('stocks.create') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
              
            <div class="col-md-2 text-right" >
                <a onclick='return $("#stock_add_modal").modal("show");' class="btn btn-inverse-primary btn-sm"><?php echo e(__("Add Stock")); ?></a>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="table-responsive">
          <table id="stock_table" class="table ">
            <thead>
              <tr>
                <th>Sr.no.</th>
                <th>Item</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Created By/Updated By</th>
                <th>Created At</th>
                <?php if(Auth::user()->hasPermissionTo('stocks.edit') || Auth::user()->hasPermissionTo('stocks.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                <th>Action</th>
                <?php endif; ?>
                
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($h->item->name); ?></td>
                    <td><?php echo e($h->prod_quantity); ?></td>
                    <td><?php echo e($h->price_for_user); ?></td>
                    
                    
                    <td><?php echo e(!empty($h->created_by)?$h->created_by_user['name']:""); ?>  <?php echo e(!empty($h->updated_by)?'/'.$h->updated_by_user->name :""); ?></td>
                    <td><?php echo e(date('d-m-Y',strtotime($h->created_at))); ?></td>
                    
                    <?php if(Auth::user()->hasPermissionTo('stocks.edit') || Auth::user()->hasPermissionTo('stocks.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                      <td>
                        <?php if(Auth::user()->hasPermissionTo('stocks.edit') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
              
                        <a onclick="edit_stock_modal('<?php echo e($h->id); ?>')" class="btn btn-success text-white">
                            <i class="mdi mdi-pen"></i>
                        </a>
                        <?php endif; ?>
                        <?php if(Auth::user()->hasPermissionTo('stocks.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
              
                        <a onclick='return $("#<?php echo e($h->id); ?>_stocks").modal("show");' class="btn btn-danger text-white">
                            <i class=" mdi mdi-delete-forever"></i>
                        </a>
                        <?php endif; ?>

                        <a onclick="return $('#<?php echo e($h->id); ?>_stock_history').modal('show');" class="btn btn-warning text-white">
                            History
                        </a>
                    </td>
                    <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project\resources\views/stocks/list.blade.php ENDPATH**/ ?>