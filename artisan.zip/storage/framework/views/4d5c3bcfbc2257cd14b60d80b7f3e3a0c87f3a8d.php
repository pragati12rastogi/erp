<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
    
      <div class="card-body">
        <div class="border-bottom mb-3 row">
            <div class="col-md-10">
                <h4 class="card-title">Expense Summary</h4>
            </div>
            <?php if(Auth::user()->hasPermissionTo('expenses.create') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN) ): ?>
            <div class="col-md-2 text-right" >
              <button onclick='return $("#add_expense_modal").modal("show");' class="btn btn-inverse-primary btn-sm"><?php echo e(__("Add Expense")); ?></button>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="table-responsive">
          <table id="expense_table" class="table ">
            <thead>
              <tr>
                <th>Sr.no.</th>
                <th>Name</th>
                <th>Amount</th>
                <th>Date Time</th>
                <th>Created By</th>
                <?php if(Auth::user()->hasPermissionTo('expenses.edit') || Auth::user()->hasPermissionTo('expenses.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                <th>Action</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($e->name); ?></td>
                    <td><?php echo e($e->amount); ?></td>
                    
                    <td><?php echo e(date('d-m-Y h:i A',strtotime($e->datetime))); ?></td>
                    <td><?php echo e(!empty($e->created_by)?$e->created_by_user['name']:""); ?></td>
                    
                    <?php if(Auth::user()->hasPermissionTo('expenses.edit') || Auth::user()->hasPermissionTo('expenses.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                
                    <td>
                      <?php if(Auth::user()->hasPermissionTo('expenses.edit') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                      
                        <a onclick='edit_expense_modal("<?php echo e($e->id); ?>")' class="btn btn-success text-white">
                            <i class="mdi mdi-pen"></i>
                        </a>
                      <?php endif; ?>
                      <?php if(Auth::user()->hasPermissionTo('expenses.destroy') || Auth::user()->hasRole(App\Custom\Constants::ROLE_ADMIN)): ?>
                      
                        <a onclick='return $("#<?php echo e($e->id); ?>_expense").modal("show");' class="btn btn-danger text-white">
                            <i class=" mdi mdi-delete-forever"></i>
                        </a>
                      <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-projects\SOS\Erp-project1\resources\views/expenses/list.blade.php ENDPATH**/ ?>