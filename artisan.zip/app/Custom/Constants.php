<?php

namespace App\Custom;

class Constants
{
    const ROLE_ADMIN = 'Admin';
}